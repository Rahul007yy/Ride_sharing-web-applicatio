<?php
$connect=mysqli_connect("localhost","root","","ride_sharing");
?>