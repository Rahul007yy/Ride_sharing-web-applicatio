<?php
session_start();
include("dbconnect.php");

if (!isset($_SESSION['uname'])) {
    die("Error: User not logged in.");
}

$uname = $_SESSION['uname'];
extract($_REQUEST);
$rdate = date("Y-m-d"); // Standardizing date format

date_default_timezone_set('Asia/Kolkata');
$currentDateTime = date('H:i:s');
$msg = "";
$finalamt = $num_seats1 * $amount;

if (isset($btn)) {
    // Validate database connection
    if (!$connect) {
        die("Database connection failed: " . mysqli_connect_error());
    }

    // Fetch latest ride request
    $q1 = mysqli_query($connect, "SELECT r.id AS rideshare_id, d.id AS request_id, r.*, d.* 
        FROM rs_rideshare AS r 
        JOIN rs_request AS d ON r.id = d.ride_id 
        WHERE d.rdate='$rdate' 
        ORDER BY d.id DESC LIMIT 1");

    if (!$q1) {
        die("Query Failed: " . mysqli_error($connect));
    }

    $n1 = mysqli_num_rows($q1);
    
    // Get the next available ID safely
    $mq = mysqli_query($connect, "SELECT MAX(id) AS max_id FROM rs_request");
    if (!$mq) {
        die("Query Failed: " . mysqli_error($connect));
    }
    
    $mr = mysqli_fetch_array($mq);
    $id = isset($mr['max_id']) ? $mr['max_id'] + 1 : 1;

    if ($n1 == 1) {
        while ($r1 = mysqli_fetch_array($q1)) {
            $num_seats_available = (int) $r1['num_seats'];
            $a_seat = (int) $r1['a_seat'];

            if ($a_seat >= $num_seats1) {
                $final_seat = $a_seat - $num_seats1;
                
                // Update seat availability
                $updateQuery = "UPDATE rs_rideshare SET a_seat='$final_seat' WHERE id='{$r1['rideshare_id']}'";
                if (!mysqli_query($connect, $updateQuery)) {
                    die("Update Failed: " . mysqli_error($connect));
                }
                
                // Insert booking request
                $insertQuery = "INSERT INTO rs_request (id, uname, ride_id, num_seats, amount, rdate, rtime) 
                    VALUES ('$id', '$uname', '{$r1['rideshare_id']}', '$num_seats1', '$finalamt', '$rdate', '$currentDateTime')";
                if (!mysqli_query($connect, $insertQuery)) {
                    die("Insert Failed: " . mysqli_error($connect));
                }

                $msg = "Booking successful!";
            } else {
                $msg = "Error: Not enough seats available.";
            }
        }
    } else {
        $msg = "Error: No available rides on this date.";
    }
}

echo $msg;
?>



<?php include("userheader.php");?>

    <div class="container-fluid pt-5">
        <div class="container pt-5">
		  <h2 class="display-4 text-uppercase mb-5">Send Request</h2>
					<h3>Rider</h3>
            <div class="row">
                <div class="col-lg-4 mb-5">
               </div>

                <div class="col-lg-6 mb-5">
			
                    <div class="bg-secondary p-5">
					
					<span style="color:#0099CC"><?php echo $msg;?></span>
						<form name="form1" method="post">
					
						<div class="form-group">
               				<label>Number of Seats</label>
							<input type="text" name="num_seats1" class="form-control px-4" placeholder="" style="height: 50px;" required>
                        </div>
						
                       
                     
                        
                        <div class="form-group mb-0">
                            <button class="btn btn-primary btn-block" type="submit" name="btn" style="height: 50px;">Submit</button>
                        </div>
						</form>
                    </div>
                </div>
				
            </div>
        </div>
    </div>
<?php include("footer.php");?>